import numpy as np

class ActivationFunction:
    def __init__(self,name, func=None, derivative=None):
        self.func = func
        self.derivative = derivative
        self.name = name

        if self.name=="sigmoid" and (not self.func):
            self.func=self.sigmoid
            self.derivative=self.sigmoid_derivative

        if self.name=="step" and (not self.func):
            self.func=self.step
            self.derivative=self.step_derivative

    def sigmoid(self,x):
        return 1 / (1 + np.exp(-x))

    def sigmoid_derivative(self,x):
        return x * (1 - x)
    
    def step(self,x):
        return 1 if x>0 else 0
    
    def step_derivative(self,x):
        return 1
    

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def sigmoid_derivative(x):
    return x * (1 - x)

sigmoid_activation1 = ActivationFunction('sigmoid',sigmoid, sigmoid_derivative)
# print(sigmoid_activation1.func(2))
# print(sigmoid_activation.func(2))


class NeuralNetwork:
    def __init__(self, architecture, activation_function):
        self.n_inputs=architecture[0]
        self.activation_function = activation_function.func
        self.layers = [Layer(n_neurons, n_inputs, self.activation_function) for n_neurons, n_inputs in zip(architecture[1:-1], architecture[:-2])]
        self.output_layer = Layer(architecture[-1], architecture[-2], self.activation_function)
        self.activation_function_derivative = activation_function.derivative

    def forward(self, inputs):
        for layer in self.layers:
            inputs = layer.forward(inputs)
        return self.output_layer.forward(inputs)


class Layer:
    def __init__(self, n_neurons, n_inputs, activation_function):
        self.neurons = [Neuron(n_inputs, activation_function) for _ in range(n_neurons)]
        self.output = None

    def forward(self, inputs):
        self.inputs = inputs
        self.output = np.array([neuron.forward(inputs) for neuron in self.neurons])
        return self.output

  
class Neuron:
    def __init__(self, n_inputs, activation_function):
        self.weights = np.random.random(n_inputs)
        self.bias = np.random.rand()
        self.output = None
        self.activation_function = activation_function

    def forward(self, inputs):
        z = np.dot( self.weights,inputs) + self.bias
        self.output = self.activation_function(z)
        return self.output
    

sigmoid_activation = ActivationFunction('sigmoid')
step_activation = ActivationFunction('step')

nn = NeuralNetwork([2, 2, 1], sigmoid_activation)

# create the XOR dataset
X = np.array([[1, 1], [1, 0], [0, 1], [0, 0]])
y = np.array([[0], [1], [1], [0]])

for inputs, expected_output in zip(X, y):
    output = nn.forward(inputs)
    output= output if output>0.7 else 0
    print(f'Inputs: {inputs}, Output: {output}, Expected Output: {expected_output}')
