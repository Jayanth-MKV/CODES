import numpy as np
import pandas as pd

np.random.seed(1)
# w=np.around(np.random.randn(2,2),2)
# w=np.around(np.random.randn(2,2),2)
# i=np.around(np.random.randn(1,2),2)
w=np.array([[ 1.74 ,-0.76],
 [ 0.32, -0.25]])
i=[[0],
 [0]] 
y=np.dot(i,w)
print(w,w.shape)
print(i,i.shape)
print(y,y.shape)

# a=np.array([[1,2],
#              [3,4]])
# b=np.array([[1,2],
#              [3,4]])
# p=[1,1]
# c=np.array(p).reshape(len(p),-1)
# d=[1,1]
# print(np.shape(p),len(p))
# print(c.shape,len(c))
# print(c)
# print(np.shape(d),len(d))
# print(np.dot(a,b))
# print(a*b)

# it=i.T
# print(w,w.shape)
# print(i,i.shape)
# print(it,it.shape)

# df=pd.read_csv("xor.csv")
# print(df)
# print(df.loc[1])
# print(df.iloc[:,1])
# for i,v in df.iterrows():
#     # print(type(v),v.shape)
#     # print(i,v)
#     i=v[0:-1]
#     # print(i)
#     a=np.array(i).reshape(-1,len(i))
#     print(a,a.shape)

# print(i*w)
# b=np.random.randn(1,len(i@w))
# print(b.shape)
# r=i@w+b
# print(r,r.shape)
# print(np.dot(i,w))

# a=np.array([[1,2,3]])
# b=np.array([[1],[2],[3]])
# print(a.shape,b.shape)
# print(np.sum(a*np.dot(a,b)))
# print(np.sum(a*b))
# print(b*a)
# print(a*b.T)
# print(b*a.T)

# print(np.around(np.random.randn(2,2),2))