class NeuralNetwork:
    pass

# layers=[2,2,1]
# layer = [print(n_neurons,n_inputs) for n_neurons, n_inputs in zip(layers, layers[:-1])]

# for n_neurons in layers:
#     print(n_neurons)

import numpy as np

# print(np.random.randn(2))
# print(np.random.randn())

# print(np.full((2,2),[3,4]))

# a=NeuralNetwork()
# a.demo="H"
# print(a)
# print(a.__dict__)
# print(a.__class__)
# print(dir(a))
# print(a.demo)

# a=np.array([[1,1],[1,2]])
# print(a.shape)
# b=np.array([[2,3],[1,2]])
# print(b.shape)
# c=[2]
# print(np.dot(a,b))
# print(a*c)

# d=np.array([[0.20234679, 0.91220073]])
# e=np.array([[-0.11719895, -0.11719895]])
# print(d*e)

a = np.array([[0.3],[-0.1]])
b = np.zeros(a.shape)
c=np.array([ 0.5249765])
d=np.array([ 0.4850045,   0.45512111])
# print(a,b,c,d)
y = np.array([ 0.4])
error = y - c 
f= error * c * (1 - c)
r=np.array(f[0]*d)
print(b,b.shape)
print(r,r.shape)
r=r.reshape(b.shape)
print(r,r.shape)
b=np.array(b)+r
# print(r,r.shape)
print(b)
