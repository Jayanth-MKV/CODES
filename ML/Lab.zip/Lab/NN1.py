import numpy as np


class Layer:
    def __init__(self, n_inputs, n_neurons):
        self.weights = np.random.randn(n_inputs, n_neurons)
        self.biases = np.random.randn(1, n_neurons)

    def calculate_output(self, input):
        self.input=np.array(input).T
        weighted_sum = np.dot(self.weights,input) + self.biases
        self.output = self.activation_function(weighted_sum)
        return self.output

    def calculate_delta(self, error, output):
        return error * self.derivative_activation_function(output)

    def update_weights(self, input, delta, learning_rate):
        # if delta.size != input.shape[0]:
        #     raise ValueError("The size of delta must be equal to the number of rows of input")
        # delta = delta.reshape(input.shape[0],-1)
        self.weights += learning_rate * np.dot(delta,input)
        self.biases += learning_rate * np.sum(delta)

    def activation_function(self, x):
        # Example: Sigmoid function
        return 1 / (1 + np.exp(-x))

    def derivative_activation_function(self, x):
        # Example: Derivative of sigmoid function
        return x * (1 - x)




class NeuralNetwork:
    def __init__(self, layers):
        # np.random.seed(1)
        self.layers = layers

    def predict(self, input):
        output = input
        for layer in self.layers:
            output = layer.calculate_output(output)
        return output

    def train(self, input, expected_output, learning_rate):
        output = self.predict(input)
        error = expected_output - output

        for i in range(len(self.layers)-1, 0, -1):
            layer = self.layers[i]
            # prev_layer = self.layers[i-1] if i>0 else 0
            input=layer.input
            output = layer.output
            # print("I",input,input.shape)
            # print("O",output)
            # print("W",layer.weights,layer.weights.shape)
            if i == len(self.layers) - 1:
                layer.delta =np.array(np.full(input.shape,layer.calculate_delta(error, output)))
                # print("Delta",i,layer.delta,layer.delta.shape)
                # layer.update_weights(input, layer.delta, learning_rate)
                layer.weights += learning_rate * (layer.delta * input)
                layer.biases += learning_rate * np.sum(layer.delta)
                # print("Updated Weights",i,layer.weights)
            else:
                next_layer = self.layers[i+1]
                layer.delta = layer.calculate_delta(np.dot(next_layer.delta, next_layer.weights.T), layer.output)
                # print("Delta",i,layer.delta,layer.delta.shape)
                layer.update_weights(input, layer.delta, learning_rate)
                # print("Updated Weights",i,layer.weights)
                # input = output
                # output = layer.calculate_output(output)
            # print(layer.delta)


# Example: Training a neural network to learn the XOR function

# Input dataset
X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
# X = np.array([[-1, -1], [-1, 1], [1, -1], [1, 1]])
# Output dataset
y = np.array([[0], [1], [1], [0]])
# y = np.array([[-1], [1], [1], [-1]])

# Define the layers of the neural network
input_layer = Layer(2, 2)
hidden_layer_1 = Layer(2, 2)
hidden_layer_2 = Layer(2, 3)
output_layer = Layer(2, 1)

# Create the neural network
nn = NeuralNetwork([input_layer, hidden_layer_1, hidden_layer_2, output_layer])

# Train the neural network
for i in range(1000):
    for j in range(len(X)):
        nn.train(X[j], y[j], 0.03)

# Test the neural network
print(nn.predict(np.array([0, 0]))) # Expected output: [0]
print(nn.predict(np.array([0, 1]))) # Expected output: [1]
print(nn.predict(np.array([1, 0]))) # Expected output: [1]
print(nn.predict(np.array([1, 1]))) # Expected output: [0]
