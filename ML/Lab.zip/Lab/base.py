import numpy as np

class Layer:
    def __init__(self, n_inputs, n_neurons):
        self.weights = None
        self.biases = None

    def activation_function(self, x):
        pass

    def derivative_activation_function(self, x):
        pass

class NeuralNetwork:
    def __init__(self, layers):
        self.layers = None

    def predict(self, input):
        pass

    def train(self, input, expected_output, learning_rate):
        pass

# Neural Network For XOR Implementation
# Input dataset
X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
# Output dataset
y = np.array([[0], [1], [1], [0]])

# Define the layers of the neural network
input_layer = Layer(2, 2)
hidden_layer_1 = Layer(2, 2)
output_layer = Layer(2, 1)

# Create the neural network
nn = NeuralNetwork([input_layer, hidden_layer_1, output_layer])

epochs=10000
learning_rate=0.001

# Train the neural network
for i in range(epochs):
    for j in range(len(X)):
        nn.train(X[j], y[j], learning_rate)


# Test the neural network
print(nn.predict(np.array([0, 0]))) # Expected output: [0]
print(nn.predict(np.array([0, 1]))) # Expected output: [1]
print(nn.predict(np.array([1, 0]))) # Expected output: [1]
print(nn.predict(np.array([1, 1]))) # Expected output: [0]